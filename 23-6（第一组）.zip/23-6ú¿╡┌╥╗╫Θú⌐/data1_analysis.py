import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
import os

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


def import_weather_data(file_path):
    """导入天气数据CSV文件，增强错误处理"""
    # 检查文件是否存在
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"找不到文件: {file_path}")

    # 定义可能的编码列表
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin1']

    for encoding in encodings:
        try:
            print(f"尝试使用 {encoding} 编码读取文件...")
            # 尝试使用指定编码读取文件，增加错误处理参数
            data = pd.read_csv(file_path, encoding=encoding, on_bad_lines='warn')
            print(f"成功使用 {encoding} 编码导入数据，共 {len(data)} 行记录")
            print("数据前几行预览：")
            print(data.head())

            # 检查必要的列是否存在
            required_columns = ['风力方向', '风级', '温度', '相对湿度']
            missing_columns = [col for col in required_columns if col not in data.columns]

            if missing_columns:
                print(f"警告：数据缺少必要的列: {missing_columns}")
                print(f"可用列: {list(data.columns)}")

            return data
        except UnicodeDecodeError:
            print(f"编码 {encoding} 尝试失败，尝试下一种编码...")
        except pd.errors.ParserError as e:
            print(f"解析错误 ({encoding}): {e}")
            print("尝试使用更宽松的解析模式...")
            try:
                # 尝试更宽松的解析
                data = pd.read_csv(file_path, encoding=encoding, on_bad_lines='skip')
                print(f"成功使用 {encoding} 编码导入数据，跳过了错误行，共 {len(data)} 行记录")
                return data
            except Exception as e2:
                print(f"宽松解析模式失败: {e2}")

    raise Exception("无法使用任何支持的编码读取文件")


def preprocess_data(data):
    """预处理数据，处理缺失值"""
    print("\n数据预处理中...")

    # 检查并显示缺失值情况
    missing_values = data.isna().sum()
    print("缺失值统计:")
    print(missing_values)

    # 对数值型列进行缺失值处理
    numeric_cols = data.select_dtypes(include=['float64', 'int64']).columns
    for col in numeric_cols:
        if missing_values[col] > 0:
            # 计算平均值（排除NaN）
            mean_value = data[col].mean(skipna=True)
            if not np.isnan(mean_value):
                print(f"用平均值 {mean_value:.2f} 填充 {col} 列的缺失值")
                data[col].fillna(mean_value, inplace=True)
            else:
                print(f"警告：{col} 列全为缺失值或无效值")

    # 检查处理后的缺失值情况
    missing_values_after = data.isna().sum()
    print("\n处理后的缺失值统计:")
    print(missing_values_after)

    return data


def wind_radar(data):
    """风向雷达图"""
    # 检查必要的列
    if '风力方向' not in data.columns or '风级' not in data.columns:
        print("错误：数据缺少风向或风速列")
        return

    wind = list(data['风力方向'])
    wind_speed = list(data['风级'])

    # 将文字风向转换为角度 - 使用字典提高效率
    wind_direction_map = {
        "北风": 90, "南风": 270, "西风": 180, "东风": 360,
        "东北风": 45, "西北风": 135, "西南风": 225, "东南风": 315
    }

    # 转换风向
    converted_wind = []
    for w in wind:
        if w in wind_direction_map:
            converted_wind.append(wind_direction_map[w])
        else:
            print(f"警告：未知风向 '{w}'，将被忽略")
            converted_wind.append(None)

    # 计算各个方向的平均风速
    degs = np.arange(45, 361, 45)
    avg_speeds = []

    for deg in degs:
        speeds = [wind_speed[i] for i, w in enumerate(converted_wind) if w == deg]
        if speeds:
            avg_speeds.append(sum(speeds) / len(speeds))
        else:
            avg_speeds.append(0)

    print("各方向平均风速:", avg_speeds)

    # 绘制雷达图
    N = 8
    theta = np.arange(0. + np.pi / 8, 2 * np.pi + np.pi / 8, 2 * np.pi / 8)
    radii = np.array(avg_speeds)

    plt.figure(figsize=(8, 8))
    ax = plt.axes(polar=True)

    # 定义颜色
    colors = [(1 - x / max(radii) if max(radii) > 0 else 0.5,
               1 - x / max(radii) if max(radii) > 0 else 0.5,
               0.6) for x in radii]

    bars = ax.bar(theta, radii, width=(2 * np.pi / N), bottom=0.0, color=colors)

    # 添加方向标签
    directions = ['东北', '东', '东南', '南', '西南', '西', '西北', '北']
    ax.set_xticks(theta)
    ax.set_xticklabels(directions)

    plt.title("一天风玫瑰图", fontsize=16)
    plt.show()


def calc_corr(a, b):
    """计算相关系数"""
    # 确保两个列表长度相同
    if len(a) != len(b):
        min_len = min(len(a), len(b))
        a = a[:min_len]
        b = b[:min_len]
        print(f"警告：输入列表长度不同，已截断为 {min_len}")

    # 过滤掉NaN值
    valid_indices = [i for i in range(len(a)) if not np.isnan(a[i]) and not np.isnan(b[i])]
    if len(valid_indices) < 2:
        print("警告：有效数据点不足，无法计算相关系数")
        return np.nan

    filtered_a = [a[i] for i in valid_indices]
    filtered_b = [b[i] for i in valid_indices]

    a_avg = sum(filtered_a) / len(filtered_a)
    b_avg = sum(filtered_b) / len(filtered_b)
    cov_ab = sum([(x - a_avg) * (y - b_avg) for x, y in zip(filtered_a, filtered_b)])
    sq = math.sqrt(sum([(x - a_avg) ** 2 for x in filtered_a]) * sum([(x - b_avg) ** 2 for x in filtered_b]))

    # 处理除零错误
    if sq == 0:
        return 0

    corr_factor = cov_ab / sq
    return corr_factor


def corr_tem_hum(data):
    """温湿度相关性分析"""
    # 检查必要的列
    if '温度' not in data.columns or '相对湿度' not in data.columns:
        print("错误：数据缺少温度或湿度列")
        return

    tem = data['温度']
    hum = data['相对湿度']

    # 检查有效数据点数量
    valid_data = data.dropna(subset=['温度', '相对湿度'])
    if len(valid_data) < 2:
        print(f"警告：有效数据点不足 ({len(valid_data)} 个)，无法进行相关性分析")
        return

    plt.figure(figsize=(10, 6))
    plt.scatter(tem, hum, color='blue', alpha=0.7)
    plt.title("温湿度相关性分析图", fontsize=16)
    plt.xlabel("温度/℃", fontsize=12)
    plt.ylabel("相对湿度/%", fontsize=12)

    # 计算相关系数
    corr = calc_corr(tem, hum)

    if not np.isnan(corr):
        plt.text(min(tem) + 1, max(hum) - 5, f"相关系数: {corr:.4f}", fontdict={'size': 12, 'color': 'red'})

    # 添加趋势线
    try:
        # 只使用有效数据点计算趋势线
        if len(valid_data) >= 2:
            z = np.polyfit(valid_data['温度'], valid_data['相对湿度'], 1)
            p = np.poly1d(z)
            plt.plot(tem, p(tem), "r--", alpha=0.7)
            plt.text(min(tem) + 1, max(hum) - 10, f"趋势线: y = {z[0]:.2f}x + {z[1]:.2f}",
                     fontdict={'size': 12, 'color': 'green'})
    except Exception as e:
        print(f"无法绘制趋势线: {e}")

    plt.grid(True, linestyle='--', alpha=0.7)
    plt.show()

    if not np.isnan(corr):
        print(f"温湿度相关系数为: {corr:.4f}")
    else:
        print("无法计算温湿度相关系数")


def main():
    # 文件路径，可以根据实际情况修改
    file_path = "weather1.csv"

    # 导入数据
    try:
        data = import_weather_data(file_path)

        # 数据预处理
        data = preprocess_data(data)

        # 分析数据
        wind_radar(data)
        corr_tem_hum(data)

        print("分析完成！")
    except Exception as e:
        print(f"程序执行出错: {e}")


if __name__ == "__main__":
    main()
